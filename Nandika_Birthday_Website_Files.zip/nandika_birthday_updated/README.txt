NANDIKA BIRTHDAY SURPRISE — UPDATED WEBSITE

Files:
- index.html (website)
- assets/ (your photos and music)

To publish on Netlify:
1. Extract this ZIP on your computer.
2. Open Netlify Drop (the same drag-and-drop deploy page you used before).
3. Drag the extracted folder named nandika_birthday_updated onto the drop area.
4. Wait for deployment to finish, then open your site link.

Secret code: 021111

Notes:
- The music may need the visitor to tap a button to start because browsers block automatic audio in some situations.
- Chapter 6 is the selfie; Chapter 7 has the dance-photo collage and slideshow.
- The song continues between Chapters 6 and 7 and stops when leaving them for Chapter 8.
